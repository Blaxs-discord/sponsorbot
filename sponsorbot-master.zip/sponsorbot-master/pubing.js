// module.js
var pubing = {};
// export it
exports.pubing = pubing;