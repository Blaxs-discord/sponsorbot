# sponsorbot
Copie du bot SponsorBot (Advertbot ) PUBLIQUE


Avant de lancer, installez les node_modules ( npm i )
Ensuite, configurez le config.json.
Vous pouvez maintenant lancer le sponsorbot.js

ce script a été développer il y a quelques mois.

Malakrovi#8543

require:
node ^12.0.0
